import jack

client = jack.Client('MyGreatClient')

# BTW on Win10 with failing installation libname tried: C:\WINDOWS\libjack64.dll