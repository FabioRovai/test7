
Here are placed older pieces of code, which were testing some one single functionality (and were later assembled together).
They might be still useful to see separated.